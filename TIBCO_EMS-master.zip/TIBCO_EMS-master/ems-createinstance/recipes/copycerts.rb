#
# Cookbook Name:: ems-createinstance
# Recipe:: copycerts
#
# Copyright (c) 2015 The Authors, All Rights Reserved.
