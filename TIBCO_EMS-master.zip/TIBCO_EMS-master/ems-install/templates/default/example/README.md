# Example

An example cookbook

## Requirements

### Platform:

*No platforms defined*

### Cookbooks:

*No dependencies defined*

## Attributes

* `node['example']['name']` -  Defaults to `Sam Doe`.

## Recipes

* example::default

## License and Maintainer

Maintainer::  (<>)

License:: All rights reserved
