name 'ems-install'
maintainer 'Jitheshkumar(JK)'
maintainer_email 'Jitheshkumar.thekkeveettil@citi.com'
license 'all_rights'
description 'Installs/Configures EMS'
long_description 'Installs/Configures TIBCO EMS'
version '0.1.0'

depends 'java', '~> 1.36.0'
