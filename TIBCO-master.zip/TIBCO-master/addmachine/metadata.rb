name 'addmachine'
maintainer 'JitheshKumar (JK)'
maintainer_email 'jiteshkumar.thekkeveettil@citi.com'
license 'all_rights'
description 'Add machine to an RV based domain'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version '0.1.0'
