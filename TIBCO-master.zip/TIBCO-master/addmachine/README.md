# addmachine

Cookbook to Add a machine to RV based domain
