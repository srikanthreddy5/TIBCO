#
# Cookbook Name:: addmachine
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe 'addmachine::commandfilexml'
include_recipe 'addmachine::domainutility'
