# createdomain

Cookbook to create a filebased domain.
