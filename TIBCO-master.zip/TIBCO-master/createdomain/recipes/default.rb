#
# Cookbook Name:: createdomain
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe 'createdomain::commandfilexml'
include_recipe 'createdomain::domainutility'
