name 'ems-install'
maintainer 'Jitheshkumar(JK)'
maintainer_email 'Jitheshkumar.thekkeveettil@citi.com'
license 'all_rights'
description 'Installs/Configures EMS'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version '0.1.0'

depends 'java', '~> 1.36.0'
