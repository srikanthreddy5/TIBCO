name 'ems-createinstance'
maintainer 'Jitheshkumar - JK'
maintainer_email 'Jitheshkumar.thekkeveettil@citi.com'
license 'all_rights'
description 'Configures EMS instances'
long_description 'Creates and Configures an EMS server instance'
version '0.1.0'

depends 'ems-install'
