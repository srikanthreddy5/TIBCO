
default['dbclient-install']['config']['s3_bucket'] = 'https://s3-us-west-2.amazonaws.com/db-client'
default['dbclient-install']['config']['db_client_version'] = 'ora11g_mysql-5.1.38'

default['dbclient-install']['config']['user'] = 'esbuser'
default['dbclient-install']['config']['group'] = 'sgsup'
default['dbclient-install']['config']['tibco_install_dir'] = '/apps/tibco'
default['dbclient-install']['config']['tra_version'] = '5.10'
