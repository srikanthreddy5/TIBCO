
default['jmsclient-install']['config']['s3_bucket'] = 'https://s3-us-west-2.amazonaws.com/ems-client'
default['jmsclient-install']['config']['ems_client_version'] = '8.2.2'

default['jmsclient-install']['config']['user'] = 'esbuser'
default['jmsclient-install']['config']['group'] = 'sgsup'
default['jmsclient-install']['config']['tibco_install_dir'] = '/apps/tibco'
default['jmsclient-install']['config']['tra_version'] = '5.10'
