#
# Cookbook Name:: tibcohome-create
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe 'tibcohome-create::users'
include_recipe 'tibcohome-create::envinfo'
