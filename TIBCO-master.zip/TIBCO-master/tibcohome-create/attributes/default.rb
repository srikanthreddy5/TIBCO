default['tibcohome-create']['config']['group'] = 'sgsup'
default['tibcohome-create']['config']['user'] = 'esbuser'

default['tibcohome-create']['config']['tibco_home_name'] = 'TIBCO_HOME'
default['tibcohome-create']['config']['tibco_home_dir'] = '/apps/tibco'
default['tibcohome-create']['config']['tibco_config_home'] = '/apps/tibco/config'
default['tibcohome-create']['config']['installer_version'] = '3.3'
