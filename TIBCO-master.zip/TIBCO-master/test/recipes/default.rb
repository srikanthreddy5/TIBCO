#
# Cookbook Name:: test
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

# include_recipe 'test::recipe1'
# include_recipe 'test::recipe2'
# include_recipe 'test::recipe3'
include_recipe 'test::recipe4'
